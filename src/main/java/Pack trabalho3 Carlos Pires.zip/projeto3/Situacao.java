package projeto3;

public class Situacao {

    private String situacao;

    public void setSituacao(String s) {
        this.situacao = s;
    }

    public String getSituacao() {
        return situacao;
    }
}
